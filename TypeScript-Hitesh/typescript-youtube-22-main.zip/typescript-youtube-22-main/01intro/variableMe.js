"use strict";
exports.__esModule = true;
var greetings = "Hello Hitesh";
greetings.toLowerCase();
console.log(greetings);
// number
var userId = 334455.3;
userId.toFixed();
// userId = "hitesh"
// boolean
var isLoggedIn = false;
