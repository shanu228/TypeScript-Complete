var myuser = { name: "hitesh", age: 10 };
console.log("Hitesh");
//console.log(user.email);
