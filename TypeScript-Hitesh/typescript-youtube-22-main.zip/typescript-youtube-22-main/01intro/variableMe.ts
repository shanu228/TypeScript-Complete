let greetings: string = "Hello Hitesh";

greetings.toLowerCase()
console.log(greetings);

// number

let userId = 334455.3

userId.toFixed()
// userId = "hitesh"
// boolean
let isLoggedIn: boolean = false



// any

let hero: string;

function getHero(){
    return "thor"
}

hero = getHero()



export {}