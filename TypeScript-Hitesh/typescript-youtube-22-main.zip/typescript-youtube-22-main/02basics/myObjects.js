"use strict";
// const User = {
//     name: "hitesh",
//     email: "hitesh@lco.dev",
//     isAvtive: true
// }
exports.__esModule = true;
var myUser = {
    _id: "1245",
    name: "h",
    email: "h@h.com",
    isActive: false
};
myUser.email = "h@gmail.com";
myUser._id = "asa";
