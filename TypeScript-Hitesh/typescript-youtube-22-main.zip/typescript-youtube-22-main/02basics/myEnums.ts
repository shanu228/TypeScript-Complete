enum SeatChoice {
    AISLE = "aisle",
    MIDDLE = 3,
    WINDOW,
    FOURTH
}

const hcSeat = SeatChoice.AISLE